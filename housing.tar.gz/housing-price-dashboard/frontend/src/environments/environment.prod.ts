export const environment = {
    production: true,
    apiUrl: '/api' // 使用相对路径，假设前后端部署在同一域
  };